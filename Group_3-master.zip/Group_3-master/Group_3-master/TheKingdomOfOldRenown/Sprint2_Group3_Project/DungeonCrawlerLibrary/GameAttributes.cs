﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DungeonCrawlerLibrary
{
    public static class GameAttributes
    {
        #region List 
        public static List<Mob> mobs = new List<Mob>();
        public static List<Weapon> weapons = new List<Weapon>();
        public static List<Potion> potions = new List<Potion>();
        public static List<Treasure> treasures = new List<Treasure>();
        public static List<Item> items = new List<Item>();
        //public static List<Room> rooms = new List<Room>();
        #endregion

        public static void FromReader()
        {
            #region Mob
            using (StreamReader fileReader = new StreamReader("Mob.csv"))
            {
                fileReader.ReadLine(); // Skips the headers in .xml file

                while (!fileReader.EndOfStream)
                {
                    var line = fileReader.ReadLine();
                    var values = line.Split(',');

                    mobs.Add(new Mob(int.Parse(values[0]), values[1], values[2], int.Parse(values[3]), int.Parse(values[4]), int.Parse(values[5])));
                }          
            }        
            #endregion

            #region Weapon
            using (StreamReader fileReader = new StreamReader("Weapon.csv"))
            {
                fileReader.ReadLine();

                while (!fileReader.EndOfStream)
                {
                    var line = fileReader.ReadLine();
                    var values = line.Split(',');

                    weapons.Add(new Weapon(int.Parse(values[0]), values[1]));
                }
            }
            #endregion

            #region Potion
            using (StreamReader fileReader = new StreamReader("Potion.csv"))
            {
                fileReader.ReadLine();

                while (!fileReader.EndOfStream)
                {
                    var line = fileReader.ReadLine();
                    var values = line.Split(',');

                    potions.Add(new Potion(int.Parse(values[0]), values[1]));
                }
            }
            #endregion

            #region Treasure
            using (StreamReader fileReader = new StreamReader("Treasure.csv"))
            {
                fileReader.ReadLine();

                while (!fileReader.EndOfStream)
                {
                    var line = fileReader.ReadLine();
                    var values = line.Split(',');

                    treasures.Add(new Treasure(int.Parse(values[0]), values[1] ));
                }
            }
            #endregion

            #region Item
            using (StreamReader fileReader = new StreamReader("Item.csv"))
            {
                fileReader.ReadLine();

                while (!fileReader.EndOfStream)
                {
                    var line = fileReader.ReadLine();
                    var values = line.Split(',');

                    items.Add(new Item(int.Parse(values[0]), values[1]));
                }
            }
            #endregion

            #region Room
            using (StreamReader fileReader = new StreamReader("Room.csv"))
            {
                fileReader.ReadLine();

                while (!fileReader.EndOfStream)
                {
                    var line = fileReader.ReadLine();
                    var values = line.Split(',');

                    rooms.Add(new Room(int.Parse(values[0]), values[1], int.Parse(values[2]), int.Parse(values[3]), int.Parse(values[4]), int.Parse(values[5]) ));
                }
                foreach (var room in rooms)
                {
                    Console.WriteLine(room.RoomName);
                }
            }
            #endregion      
            Console.ReadLine();
        }

        #region Menu
        public static List<Menu> menu = new List<Menu>()
        {           
            new Menu("Type 'Room' to see all Rooms!"),
            new Menu("Type 'Quit' to exit the game!"),
            new Menu("Type 'Location' to see where you are!"),
            new Menu("Type 'Weapons' to see weapons!"),
            new Menu("Type 'Potions' to see Potions!"),
            new Menu("Type 'Treasures' to see Treasures!"),
            new Menu("Type 'Items' to see Items!"),
            new Menu("Type 'Mobs' to see Monsters!")
        };
        #endregion

        public static List<Room> rooms = new List<Room>()
        {
            new Room(1, "entrance", 1, -1, -1, -1),
            new Room(2, "room1",    2,  0,  4, -1),
            new Room(3, "room2",   -1,  1,  3, -1),
            new Room(4, "room3",   -1,  4, -1,  2),
            new Room(5, "room4",    3, -1, -1,  1)
        };

        //public static List<Weapon> weapons = new List<Weapon>()
        //{
        //    new Weapon(6, "Rusty Blade"),
        //    new Weapon(7, "Warped Staff"),
        //    new Weapon(8, "Worn Bow"),
        //    new Weapon(9, "Old Dagger")
        //};

        //public static List<Potion> potions = new List<Potion>()
        //{
        //    new Potion(1,  "Health Potion"),
        //    new Potion(11, "Mana Potion")
        //};

        //public static List<Treasure> treasures = new List<Treasure>()
        //{
        //    new Treasure(12, "Rusty Armor"),
        //    new Treasure(13, "Training Robes"),
        //    new Treasure(14, "Leather Armor")
        //};

        //public static List<Item> items = new List<Item>()
        //{
        //    new Item(15,"Home Beacon"),
        //    new Item(16,"Coin Pouch"),
        //    new Item(17,"Lock Pick"),
        //    new Item(18,"Tinderbox")
        //};

        //public static List<Mob> mobs = new List<Mob>()
        //{
        //    new Mob(15, "Goblin"),
        //    new Mob(16, "Sewer Rats"),
        //    new Mob(17, "Giant Spider"),
        //    new Mob(18, "Skeleton")
        //};

    }
}
