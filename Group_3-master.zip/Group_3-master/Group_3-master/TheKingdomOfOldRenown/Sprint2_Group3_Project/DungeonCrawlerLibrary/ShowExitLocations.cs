﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawlerLibrary
{
    public class ShowExitLocations
    {
        public static void DisplayExits()
        {
            Console.WriteLine("You are at {0}", Player.CurrentRoom.RoomName);
            List<string> exits = new List<string>();
            if (Player.CurrentRoom.North != -1)
            {
                exits.Add("North");
            }
            if (Player.CurrentRoom.South != -1)
            {
                exits.Add("South");
            }
            if (Player.CurrentRoom.East != -1)
            {
                exits.Add("East");
            }
            if (Player.CurrentRoom.West != -1)
            {
                exits.Add("West");
            }

            List<char> displayExits = new List<char>();
            foreach (string oldExits in exits)
            {
                displayExits.AddRange(oldExits);
            }
            foreach (char letter in displayExits)
            {
                if (char.IsUpper(letter) && displayExits.Count > 0)
                {
                    displayExits.Append(',');
                    displayExits.Append(' ');
                }
                displayExits.Append(letter);
            }

            Console.Write("You see Exits: ");
            for (int index = 0; index < displayExits.Count; index++)
            {
                Console.Write(displayExits[index]);
            }

        }
    }
}
