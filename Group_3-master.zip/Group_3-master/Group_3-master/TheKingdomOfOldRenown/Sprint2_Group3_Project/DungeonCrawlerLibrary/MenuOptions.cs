﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawlerLibrary
{
    public class MenuOptions
    {
        public static void DisplayMenu(string input)
        {
            while (input == "menu")
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                foreach (Menu name in GameAttributes.menu)
                {
                    Console.WriteLine(name.Options);
                }
                Console.ForegroundColor = ConsoleColor.White;

                Console.Write("\nPlease enter what you would like to do: > ");
  
                input = Console.ReadLine().ToLower();
                
                if (input.ToLower() == "room")
                {
                    foreach (Room name in GameAttributes.rooms)
                    {
                        Console.WriteLine(name.RoomName);     
                    }
                }
                else if (input.ToLower() == "location")
                {
                    Console.WriteLine($"You are Currently in {Player.CurrentRoom.RoomName}");
                }
                else if (input.ToLower() == "weapons")
                {
                    foreach (Weapon name in GameAttributes.weapons)
                    {
                        Console.WriteLine(name.Name);
                    }
                }
                else if (input.ToLower() == "potions")
                {
                    foreach (Potion name in GameAttributes.potions)
                    {
                        Console.WriteLine(name.Name);
                    }
                }
                else if (input.ToLower() == "treasures")
                {
                    foreach (Treasure name in GameAttributes.treasures)
                    {
                        Console.WriteLine(name.Name);
                    }
                }
                else if (input.ToLower() == "items")
                {
                    foreach (Item name in GameAttributes.items)
                    {
                        Console.WriteLine(name.Name);
                    }
                }
                else if (input.ToLower() == "mobs")
                {
                    foreach (Mob mob in GameAttributes.mobs)
                    {
                        Console.WriteLine(mob.Name);
                    }
                }
                else
                {
                    Console.WriteLine("Not a Valid input! Type 'Menu' to display a menu!");
                }
            }
        }
    }
}
