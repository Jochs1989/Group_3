﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawlerLibrary
{
    public class Room
    {
        public int ID { get; set; }
        public string RoomName { get; set; }
        public int North { get; set; }
        public int South { get; set; }
        public int East { get; set; }
        public int West { get; set; }

        public Room(int id, string roomName, int north, int south, int east, int west)
        {
            ID = id;
            RoomName = roomName;
            North = north;
            South = south;
            East = east;
            West = west;
        }
    }
}
