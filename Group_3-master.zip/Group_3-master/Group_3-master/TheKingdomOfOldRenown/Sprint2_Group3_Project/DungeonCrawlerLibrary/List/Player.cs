﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawlerLibrary
{
    public class Player
    {
        public static Room CurrentRoom { get; set; }
         
        public Player()
        {
            CurrentRoom = GameAttributes.rooms[0];    // List index out of range ??
        }
    }
}
