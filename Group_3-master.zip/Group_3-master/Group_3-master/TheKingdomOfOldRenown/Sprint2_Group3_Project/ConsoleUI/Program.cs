﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DungeonCrawlerLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            GameAttributes.FromReader();

            Player currentRoom = new Player();

            bool exit = false;

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Type 'Menu' to see the Menu\n");

            Console.WriteLine("Type 'Quit' to quit the game\n");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\nYou are currently at {0}.\nPlease Enter (North, South, East, West) to move!\n", Player.CurrentRoom.RoomName);
            do
            {
                ShowExitLocations.DisplayExits();
                Console.Write("\nPlease enter what you would like to do: > ");
                string input = Console.ReadLine().ToLower();

                if (input == "quit")
                {
                    exit = true;
                }
                else if (input == "menu")
                {
                    MenuOptions.DisplayMenu(input);
                }
                else if (input != "menu")
                {
                    PlayerMovement.DisplayMovement(input);
                }
                else
                {
                    Console.WriteLine("Not a Valid input! Type 'Menu' to display a menu!");
                }

            } while (exit == false);

        }
    }
}
