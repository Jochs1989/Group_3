﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawlerLibrary
{
    public class PlayerMovement
    {
        public static string DisplayMovement(string input)
        {
            

            if (input.ToLower() == "north")
            {
                if (Player.CurrentRoom.North != -1)
                {
                    Player.CurrentRoom = GameAttributes.rooms[Player.CurrentRoom.North];
                }
                else
                {
                    Console.WriteLine("\nYou are looking at a wall\n");
                }
            }
            else if (input.ToLower() == "south")
            {
                if (Player.CurrentRoom.South != -1)
                {
                    Player.CurrentRoom = GameAttributes.rooms[Player.CurrentRoom.South];
                }
                else
                {
                    Console.WriteLine("\nYou are looking at a wall\n");
                }
            }
            else if (input.ToLower() == "east")
            {
                if (Player.CurrentRoom.East != -1)
                {
                    Player.CurrentRoom = GameAttributes.rooms[Player.CurrentRoom.East];
                }
                else
                {
                    Console.WriteLine("\nYou are looking at a wall\n");
                }
            }
            else if (input.ToLower() == "west")
            {
                if (Player.CurrentRoom.West != -1)
                {
                    Player.CurrentRoom = GameAttributes.rooms[Player.CurrentRoom.West];
                }
                else
                {
                    Console.WriteLine("\nYou are looking at a wall\n");
                }
            }
            else
            {
                Console.WriteLine("Not a Valid Direction");
            }

            return input;
        }
    }
}
